#!/usr/bin/env python3
"""Backport the released Service Finder Workflow into the Services modules."""
from __future__ import annotations

import json
from pathlib import Path

import divi_modules

BASE = Path("/home/dioscarr/Work/divi-working-set")
RELEASE = BASE / "releases/bdstar-contact-service-finder-v1.json"
SERVICES = BASE / "Modules/services"
SECTIONS = SERVICES / "sections"


def main() -> None:
    payload = next(iter(json.loads(RELEASE.read_text(encoding="utf-8"))["data"].values()))
    finder = None
    for start, end, label in divi_modules.top_level_sections(payload):
        if label == "Service Finder Workflow":
            finder = payload[start:end].rstrip() + "\n"
            break
    if finder is None:
        raise SystemExit("Service Finder Workflow section not found in release")

    (SECTIONS / "02-service-finder-workflow.divi").write_text(finder, encoding="utf-8")

    hero_path = SECTIONS / "01-services-split-hero.divi"
    hero = hero_path.read_text(encoding="utf-8")
    hero = hero.replace(
        '"phone":{"value":{"padding":{"top":"0px","bottom":"0px","left":"","right":"","syncVertical":"off","syncHorizontal":"off"}}}',
        '"phone":{"value":{"padding":{"top":"0px","bottom":"32px","left":"","right":"","syncVertical":"off","syncHorizontal":"off"}}}',
        1,
    )
    hero_path.write_text(hero, encoding="utf-8")

    manifest_path = SERVICES / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    parts = manifest["parts"]
    parts = [part for part in parts if part.get("file") != "sections/02-service-finder-workflow.divi"]
    insert_at = 1
    parts[insert_at:insert_at] = [
        {"kind": "raw", "file": None, "text": "\n\n", "label": None},
        {
            "kind": "section",
            "file": "sections/02-service-finder-workflow.divi",
            "text": None,
            "label": "Service Finder Workflow",
        },
    ]
    manifest["parts"] = parts
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print("Services module rebuilt with Service Finder Workflow and mobile hero padding.")


if __name__ == "__main__":
    main()
